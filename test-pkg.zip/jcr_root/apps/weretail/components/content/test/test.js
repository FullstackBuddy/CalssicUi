"use strict"; use(function () { 

    var count = {},
    properties = granite.resource.properties; count = properties["itemCount"]; 

       if(count == "2"){ count = [1,2]; } 
       if(count == "3"){ count = [1,2,3]; } 
      if(count == "4"){ count = [1,2,3,4]; } 
      if(count == "5"){ count = [1,2,3,4,5]; } return count; });

/*"use strict";
use(function () {
    var count = properties["itemCount"];

    return new Array(Number(count));

});*/